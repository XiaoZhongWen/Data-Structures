/**
 判断括号是否匹配 {} [] ()
 
 Author: Smallfly
 */
#import <Foundation/Foundation.h>

@interface BalancedParentheses : NSObject

- (BOOL)checkForParenthessBlanced:(NSString *)express;

@end
